package com.advgm.mapper;

import com.advgm.domain.CrReservoir;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface CrReservoirMapper extends BaseMapper<CrReservoir> {
}
