package com.advgm.service;

import com.advgm.domain.SysUserLog;
import com.baomidou.mybatisplus.extension.service.IService;

public interface SysUserLogService extends IService<SysUserLog> {
}
