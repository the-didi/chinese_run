package com.advgm.service;

import com.advgm.domain.SysUserRole;
import com.baomidou.mybatisplus.extension.service.IService;
public interface SysUserRoleService extends IService<SysUserRole>{


}
