package com.advgm.mapper;

import com.advgm.domain.SysUserLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface SysUserLogMapper extends BaseMapper<SysUserLog> {
}
