package com.advgm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.advgm.domain.SysUserRole;

public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {
}