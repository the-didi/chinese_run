package com.advgm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.advgm.domain.SysRolePrivilege;

public interface SysRolePrivilegeMapper extends BaseMapper<SysRolePrivilege> {
}