package com.advgm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.advgm.domain.SysRoleMenu;

public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {
}