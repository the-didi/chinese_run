package com.advgm.mapper;

import com.advgm.domain.Driver;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * @author 袁鹏
 * @date 2022年05月03日 14:44
 */

public interface DriverMapper extends BaseMapper<Driver> {

}