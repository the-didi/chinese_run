package com.advgm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.advgm.domain.SysRolePrivilegeUser;

public interface SysRolePrivilegeUserMapper extends BaseMapper<SysRolePrivilegeUser> {
}